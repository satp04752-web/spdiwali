import tkinter as tk
from tkinter import messagebox
import random
from pathlib import Path

# Optional music library
try:
    import pygame
    MUSIC_AVAILABLE = True
except ImportError:
    MUSIC_AVAILABLE = False


# ---------------- MAIN WINDOW ----------------

root = tk.Tk()
root.title("sat's Diwali Wonderland 3.0")
root.geometry("620x780")
root.minsize(500, 680)
root.configure(bg="#190600")

BG = "#190600"
GOLD = "#FFD700"
WHITE = "#FFF4D6"
ORANGE = "#FF9900"

music_playing = False
music_initialized = False

# ---------------- CONTENT ----------------

jokes = [
    "😂 Iss Diwali mithai kam khana... warna sweets tumhe kha jayengi!",
    "🤣 Lakshmi ji aaye ya na aaye, WiFi fast rehna chahiye!",
    "🎆 Tumhari smile crackers se bhi zyada bright hai!",
    "😂 Iss Diwali bas khushiyan blast honi chahiye!",
    "🤣 Shopping ka bill dekhkar asli shock lagta hai!",
    "🪔 Happiness ka unlimited recharge ho tumhari life mein!"
]

surprises = [
    "🎁 Surprise! Tum duniya ke sabse special logon mein se ho!",
    "✨ May your dreams turn into beautiful realities!",
    "💛 Aaj ka mission: Smile karo aur mithai enjoy karo!",
    "🎆 Warning: Happiness overload incoming!",
    "🌟 You deserve all the happiness in the world!"
]


# ---------------- TITLE ----------------

title = tk.Label(
    root,
    text="🪔 DIWALI HAI DIWALI 🪔",
    font=("Georgia", 27, "bold"),
    fg=GOLD,
    bg=BG
)
title.pack(pady=(20, 5))

subtitle = tk.Label(
    root,
    text="A Magical Celebration of Lights & Happiness ✨",
    font=("Arial", 11),
    fg=WHITE,
    bg=BG
)
subtitle.pack(pady=5)


# ---------------- ANIMATION CANVAS ----------------

canvas = tk.Canvas(
    root,
    width=570,
    height=180,
    bg=BG,
    highlightthickness=0
)
canvas.pack(pady=10)

# Draw diyas
canvas.create_text(
    145, 115,
    text="🪔",
    font=("Arial", 48)
)

canvas.create_text(
    425, 115,
    text="🪔",
    font=("Arial", 48)
)

canvas.create_text(
    285, 85,
    text="✨ HAPPY DIWALI ✨",
    fill=GOLD,
    font=("Georgia", 21, "bold")
)

# Create stars
stars = []

for i in range(35):
    x = random.randint(5, 565)
    y = random.randint(5, 170)
    size = random.randint(2, 4)

    star = canvas.create_oval(
        x, y, x + size, y + size,
        fill=GOLD,
        outline=""
    )

    stars.append(star)


def animate_stars():
    for star in stars:
        canvas.move(
            star,
            random.randint(-1, 1),
            random.randint(-1, 1)
        )

        x1, y1, x2, y2 = canvas.coords(star)

        if x1 < 0:
            canvas.move(star, 560, 0)
        elif x1 > 570:
            canvas.move(star, -560, 0)

        if y1 < 0:
            canvas.move(star, 0, 170)
        elif y1 > 180:
            canvas.move(star, 0, -170)

        canvas.itemconfig(
            star,
            fill=random.choice(
                [GOLD, ORANGE, WHITE]
            )
        )

    root.after(150, animate_stars)


# ---------------- FIREWORKS ----------------

def fireworks():
    x = random.randint(60, 510)
    y = random.randint(20, 150)

    colors = [
        "gold", "orange", "#ff4d6d",
        "#00ffff", "#ffffff"
    ]

    for i in range(12):
        angle = i * 30
        color = random.choice(colors)

        particle = canvas.create_text(
            x, y,
            text="✦",
            fill=color,
            font=("Arial", 15)
        )

        dx = random.uniform(-4, 4)
        dy = random.uniform(-4, 4)

        def move_particle(
            p=particle,
            vx=dx,
            vy=dy,
            count=0
        ):
            if count < 15:
                canvas.move(p, vx, vy)
                root.after(
                    45,
                    lambda: move_particle(
                        p, vx * 0.92, vy * 0.92,
                        count + 1
                    )
                )
            else:
                canvas.delete(p)

        move_particle()


def automatic_fireworks():
    fireworks()
    root.after(1800, automatic_fireworks)


# ---------------- NAME INPUT ----------------

name_label = tk.Label(
    root,
    text="Who's getting this magical wish? 😎",
    font=("Arial", 14, "bold"),
    fg=WHITE,
    bg=BG
)
name_label.pack(pady=10)

name_entry = tk.Entry(
    root,
    font=("Arial", 15),
    justify="center",
    width=27,
    bg="#FFF0C5",
    fg="#4B1600",
    relief="flat"
)
name_entry.pack(pady=8)


# ---------------- RESULT BOX ----------------

result = tk.Label(
    root,
    text="🎁 Enter your name to unlock a surprise!",
    font=("Georgia", 12),
    fg=WHITE,
    bg="#421500",
    wraplength=490,
    justify="center",
    padx=15,
    pady=20,
    height=7
)
result.pack(padx=25, fill="x", pady=15)


# ---------------- SURPRISE BUTTON ----------------

def surprise():
    name = name_entry.get().strip()

    if not name:
        result.config(
            text="😂 Oye mystery person! Pehle apna naam batao!"
        )
        return

    result.config(
        text=f"""
🪔 HAPPY DIWALI {name.upper()}! 🪔

✨ May your life shine brighter
than a thousand stars!

🙏 May Maa Lakshmi bless your home
with peace and prosperity.

🎁 YOUR SPECIAL SURPRISE:

{random.choice(surprises)}

🎆 Keep Smiling, Keep Shining!

❤️ With lots of love!
"""
    )

    fireworks()


# ---------------- FUNNY BUTTON ----------------

def funny():
    result.config(text=random.choice(jokes))
    fireworks()


# ---------------- BUTTON STYLE ----------------

def make_button(text, command):
    return tk.Button(
        root,
        text=text,
        command=command,
        font=("Arial", 12, "bold"),
        bg=GOLD,
        fg="#421500",
        activebackground=ORANGE,
        activeforeground="white",
        relief="flat",
        padx=18,
        pady=10,
        cursor="hand2"
    )


make_button(
    "🎁 OPEN MY SURPRISE",
    surprise
).pack(pady=6)

make_button(
    "😂 MAKE ME LAUGH",
    funny
).pack(pady=6)


# ---------------- SOFT MUSIC ----------------

def toggle_music():
    global music_playing, music_initialized

    if not MUSIC_AVAILABLE:
        messagebox.showinfo(
            "Music",
            "Install pygame first:\npip install pygame"
        )
        return

    music_file = Path(__file__).parent / "soft_instrumental.mp3"

    if not music_file.exists():
        messagebox.showinfo(
            "Music file missing",
            "Place your soft instrumental MP3 file\n"
            "in the same folder as this Python file.\n\n"
            "Name it: soft_instrumental.mp3"
        )
        return

    try:
        if not music_initialized:
            pygame.mixer.init()
            music_initialized = True

        if music_playing:
            pygame.mixer.music.stop()
            music_playing = False
            music_button.config(text="🎵 MUSIC ON")
        else:
            pygame.mixer.music.load(str(music_file))
            pygame.mixer.music.play(-1)
            music_playing = True
            music_button.config(text="🔇 MUSIC OFF")

    except Exception as error:
        messagebox.showerror("Music Error", str(error))


music_button = make_button(
    "🎵 MUSIC ON",
    toggle_music
)
music_button.pack(pady=8)


# ---------------- CREATOR SIGNATURE ----------------

signature = tk.Label(
    root,
    text="✨ Created with ❤️ by Sat Parkash ✨",
    font=("Georgia", 12, "italic"),
    fg=GOLD,
    bg=BG
)
signature.pack(side="bottom", pady=20)


# ---------------- START ANIMATIONS ----------------

animate_stars()
automatic_fireworks()

root.mainloop()
